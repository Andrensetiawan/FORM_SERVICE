"use client";

import InputField from "@/components/inputfield";
import FormSection from "@/components/formsection";
import Navbar from "@/components/navbar";
import { useState } from "react";

export default function Home() {
  // Gabungkan semua state dalam satu objek formData
  const [formData, setFormData] = useState({
    // Data Customer
    nama: "",
    alamat: "",
    no_hp: "",
    email: "",
    
    // Data Unit
    merk: "",
    tipe: "",
    serial_number: "",
    keluhan: "",
    spesifikasi_teknis: "",
    
    // Jenis Perangkat
    jenis_perangkat: [] as string[],
    keterangan_perangkat: "",
    
    // Accessories - gabungkan ke dalam formData
    accessories: ["Baterai", "Adaptor"] as string[],
    keterangan_accessories: "",
    
    // Garansi
    garansi: false,
    keterangan_garansi: "",
    
    // Kondisi
    kondisi: [] as string[],
    keterangan_kondisi: "",
    
    // Info Tambahan
    prioritas_service: "1. Reguler",
    track_number: "",
    penerima_service: ""
  });

  // Handle perubahan input text/textarea
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle checkbox untuk jenis perangkat
  const handleJenisPerangkat = (device: string) => {
    setFormData(prev => {
      const jenis_perangkat = prev.jenis_perangkat.includes(device)
        ? prev.jenis_perangkat.filter(x => x !== device)
        : [...prev.jenis_perangkat, device];
      
      return { ...prev, jenis_perangkat };
    });
  };

  // Handle checkbox untuk kondisi
  const handleKondisi = (condition: string) => {
    setFormData(prev => {
      const kondisi = prev.kondisi.includes(condition)
        ? prev.kondisi.filter(x => x !== condition)
        : [...prev.kondisi, condition];
      
      return { ...prev, kondisi };
    });
  };

  // Handle radio untuk garansi
  const handleGaransi = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      garansi: e.target.value === "Ya"
    }));
  };

  // Handle accessories - sekarang bagian dari formData
  const handleAccessories = (item: string) => {
    setFormData(prev => {
      const accessories = prev.accessories.includes(item)
        ? prev.accessories.filter(x => x !== item)
        : [...prev.accessories, item];
      
      return { ...prev, accessories };
    });
  };

  // Handle submit form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Kirim seluruh formData
      const res = await fetch("/api/service", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }

      const result = await res.json() as {
        success: boolean;
        message: string;
        data?: { id: number };
      };
      
      console.log("Respon API:", result);
      
      if (result.success) {
        alert(`Data berhasil disimpan dengan ID: ${result.data?.id}`);
      } else {
        alert(`Gagal: ${result.message}`);
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      alert("Gagal mengirim data. Silakan coba lagi.");
    }
  };

  return (
    <div className="bg-white min-h-screen">
      {/* Navbar */}
      <Navbar />

      {/* Main */}
      <main className="max-w-4xl w-full mx-auto p-6 space-y-6">
        <div className="text-center text-black">
          <h1 className="text-2xl font-bold">Selamat datang di Layanan Service Kami</h1>
          <p>Cepat, Mudah, dan Terpercaya!</p>
        </div>

        {/* FORM */}
        <form className="space-y-6 text-black" onSubmit={handleSubmit}>
          {/* Data Customer */}
          <FormSection title="Data Customer">
            <InputField 
              label="Nama" 
              placeholder="Nama" 
              name="nama"
              value={formData.nama}
              onChange={handleInputChange}
            />
            <InputField 
              label="Alamat" 
              placeholder="Alamat" 
              textarea 
              name="alamat"
              value={formData.alamat}
              onChange={handleInputChange}
            />
            <InputField 
              label="No. Handphone" 
              placeholder="No. Handphone" 
              name="no_hp"
              value={formData.no_hp}
              onChange={handleInputChange}
            />
            <InputField 
              label="Email" 
              placeholder="Email" 
              name="email"
              value={formData.email}
              onChange={handleInputChange}
            />
          </FormSection>

          {/* Data Perangkat */}
          <FormSection title="Data Perangkat">
            <InputField 
              label="Merk" 
              placeholder="Merk" 
              name="merk"
              value={formData.merk}
              onChange={handleInputChange}
            />
            <InputField 
              label="Tipe" 
              placeholder="Tipe" 
              name="tipe"
              value={formData.tipe}
              onChange={handleInputChange}
            />
            <InputField 
              label="Serial Number" 
              placeholder="Serial Number" 
              name="serial_number"
              value={formData.serial_number}
              onChange={handleInputChange}
            />
            <InputField 
              label="Keluhan" 
              placeholder="Keluhan" 
              textarea 
              name="keluhan"
              value={formData.keluhan}
              onChange={handleInputChange}
            />
            <InputField 
              label="Spesifikasi Teknis" 
              placeholder="Spesifikasi Teknis" 
              textarea 
              name="spesifikasi_teknis"
              value={formData.spesifikasi_teknis}
              onChange={handleInputChange}
            />
          </FormSection>

          {/* Jenis Perangkat */}
          <FormSection title="Jenis Perangkat">
            <div className="flex flex-wrap gap-4">
              {["Laptop", "PC", "UPS", "Console"].map((device) => (
                <label key={device} className="flex items-center space-x-2">
                  <input 
                    type="checkbox" 
                    className="w-4 h-4"
                    checked={formData.jenis_perangkat.includes(device)}
                    onChange={() => handleJenisPerangkat(device)}
                  />
                  <span>{device}</span>
                </label>
              ))}
            </div>
            <InputField 
              label="Keterangan" 
              placeholder="Keterangan" 
              name="keterangan_perangkat"
              value={formData.keterangan_perangkat}
              onChange={handleInputChange}
            />
          </FormSection>

          {/* Accessories */}
          <FormSection title="Accessories">
            <div className="flex flex-wrap gap-4">
              {["Baterai", "Adaptor", "Tas", "Casing", "Mouse", "Receiver"].map(
                (acc) => (
                  <label key={acc} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={formData.accessories.includes(acc)}
                      onChange={() => handleAccessories(acc)}
                      className="w-4 h-4"
                    />
                    <span>{acc}</span>
                  </label>
                )
              )}
            </div>
            <InputField 
              label="Keterangan" 
              placeholder="Keterangan" 
              name="keterangan_accessories"
              value={formData.keterangan_accessories}
              onChange={handleInputChange}
            />
          </FormSection>

          {/* Garansi */}
          <FormSection title="Garansi">
            <div className="flex space-x-6">
              <label className="flex items-center space-x-2">
                <input 
                  type="radio" 
                  name="garansi" 
                  value="Ya"
                  checked={formData.garansi === true}
                  onChange={handleGaransi}
                  className="w-4 h-4" 
                />
                <span>Ya</span>
              </label>
              <label className="flex items-center space-x-2">
                <input 
                  type="radio" 
                  name="garansi" 
                  value="Tidak"
                  checked={formData.garansi === false}
                  onChange={handleGaransi}
                  className="w-4 h-4" 
                />
                <span>Tidak</span>
              </label>
            </div>
            <InputField 
              label="Keterangan Garansi" 
              placeholder="Keterangan" 
              name="keterangan_garansi"
              value={formData.keterangan_garansi}
              onChange={handleInputChange}
            />
          </FormSection>

          {/* Kondisi */}
          <FormSection title="Kondisi Saat Masuk">
            <div className="grid grid-cols-2 gap-3">
              {[
                "Mati Total", "Layar Gelap", "Layar Biru", "Bekas Jatuh",
                "Chasing Pecah", "Pernah Dibongkar", "Baret", "Retak",
                "Kotor / Berdebu",
              ].map((condition) => (
                <label key={condition} className="flex items-center space-x-2">
                  <input 
                    type="checkbox" 
                    className="w-4 h-4"
                    checked={formData.kondisi.includes(condition)}
                    onChange={() => handleKondisi(condition)}
                  />
                  <span>{condition}</span>
                </label>
              ))}
            </div>
            <InputField 
              label="Keterangan" 
              placeholder="Keterangan" 
              name="keterangan_kondisi"
              value={formData.keterangan_kondisi}
              onChange={handleInputChange}
            />
          </FormSection>

          {/* Info Tambahan */}
          <FormSection title="Info Tambahan">
            <InputField 
              label="Prioritas Service" 
              placeholder="1. Reguler" 
              name="prioritas_service"
              value={formData.prioritas_service}
              onChange={handleInputChange}
            />
            <InputField 
              label="Track Number" 
              placeholder="Track Number" 
              name="track_number"
              value={formData.track_number}
              onChange={handleInputChange}
            />
            <InputField 
              label="Penerima Service" 
              placeholder="Penerima Service" 
              name="penerima_service"
              value={formData.penerima_service}
              onChange={handleInputChange}
            />
          </FormSection>

          {/* Submit */}
          <div className="flex space-x-4">
            <button
              type="submit"
              className="bg-blue-600 text-white px-4 py-2 rounded-md shadow hover:bg-blue-700"
            >
              Submit Only
            </button>
          </div>
        </form>
      </main>
    </div>
  );
}